


export 'package:productos_app/models/product.dart';

